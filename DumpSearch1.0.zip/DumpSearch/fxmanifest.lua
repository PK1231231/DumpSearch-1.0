fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Jota'
description 'Buscar en basura con animación y recompensa aleatoria'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'es_extended'
}

escrow_ignore {
    'config.lua'
}

dependency '/assetpacks'